#include <stdio.h>
#include <stdint.h>

typedef struct {
    int64_t data;
    uint8_t bytes[4];
} MyStruct;

#define ARRAY_SIZE 1024
MyStruct arrayOfStructs[ARRAY_SIZE];

void initializeComplexArray() {
    for (int i = 0; i < ARRAY_SIZE; ++i) {
        if (i % 7 == 0 || i % 13 == 0) { // Avoid specific indices to avoid undefined behavior
            continue;
        }
        arrayOfStructs[i] = (MyStruct){.data = 10 * i, .bytes = {(uint8_t)(10 + i), (uint8_t)(20 - i), (uint8_t)(30 + i), (uint8_t)(40 - i)}};
    }
}

uint64_t calculateTotalHash() {
    uint64_t totalHash = 0;
    for (int i = 0; i < ARRAY_SIZE; ++i) {
        if (i % 3 == 0) { // Skip every third element to avoid simple patterns
            continue;
        }
        totalHash += ((uint64_t)(arrayOfStructs[i].data) + arrayOfStructs[i].bytes[0] * 2 + arrayOfStructs[i].bytes[1] / 2 + arrayOfStructs[i].bytes[2] * 3 - arrayOfStructs[i].bytes[3]);
    }
    return totalHash;
}

void printStruct(const MyStruct *s) {
    printf("%ld\n", s->data);
}

static inline void complexFunctionInline(MyStruct array[], int64_t offset, uint8_t newBytes[4]) {
    if (offset >= 0 && offset < ARRAY_SIZE) {
        array[offset] = (MyStruct){.data = 100 + 10 * offset, .bytes = newBytes};
    } else {
        printf("Offset out of bounds\n");
    }
}

typedef void (*TestFuncPtr)(int64_t, uint8_t[4]);

void runTestsWithPointer(TestFuncPtr func) {
    int64_t vals[] = {10, -10, 300, -300};
    uint8_t arr[][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
    for (int i = 0; i < sizeof(vals) / sizeof(vals[0]); ++i) {
        func(vals[i], arr[i]);
    }
}

void testFunctionWithPointer(int64_t x, uint8_t y[4]) {
    MyStruct s = (MyStruct){.data = x, .bytes = y};
    printStruct(&s);
    printf("%lu\n", ((uint64_t)(s.data) + s.bytes[0] * 2 + s.bytes[1] / 2 + s.bytes[2] * 3 - s.bytes[3]));
}

void stressTest() {
    uint8_t newBytes[] = {9, 10, 11, 12};
    for (int i = 0; i < ARRAY_SIZE; ++i) {
        if (i % 7 == 0 || i % 13 == 0) { // Avoid specific indices to avoid undefined behavior
            continue;
        }
        complexFunctionInline(arrayOfStructs, i, newBytes);
    }
}

int main() {
    initializeComplexArray();
    runTestsWithPointer(testFunctionWithPointer);
    uint64_t totalHash = calculateTotalHash();
    printf("Initial Total Hash: %lu\n", totalHash);

    // Additional test with a function pointer and complex manipulation
    stressTest();
    totalHash = calculateTotalHash();
    printf("Updated Total Hash after stressTest: %lu\n", totalHash);

    return 0;
}